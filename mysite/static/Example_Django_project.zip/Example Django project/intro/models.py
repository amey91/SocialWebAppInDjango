from django.db import models

# This application has no data models.
